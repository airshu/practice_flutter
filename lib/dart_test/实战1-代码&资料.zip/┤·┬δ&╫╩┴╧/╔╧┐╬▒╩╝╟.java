

同学们好，欢迎来到享学课堂，我是今天的主讲 Leo老师，

我们正式 上课的时间 20：05，已经进来的同学请耐心等候下其他同学

flutter 进阶  录播



sdk:2.12 -- 判空 

flutter  UI框架

状态管理 Provider

数据共享

class InheritedProvider<T> extends InheritedWidget

class ChangeNotifierProvider<T extends ChangeNotifier> extends StatefulWidget

class _ChangeNotifierProviderState<T extends ChangeNotifier>
    extends State<ChangeNotifierProvider<T>>


class CartModel extends ChangeNotifier


data: CartModel() --》 ViewModel


CartModel(),管理数据 --》 更新Ui


ChangeNotifierProvider --- 提供内容 -- 被观察者

CartModel

UI

会用 --- 干什么 -- 理解原理


get -- 路由管理


















