


同学们好，欢迎来到享学课堂，我是今天的主讲 Leo老师，

我们正式 上课的时间 20：05，已经进来的同学请耐心等候下其他同学



flutter --- 
1.基础录播
2.开眼视频的实战
3.进阶录播 -- 可能安排如下：
    1.混合开发
    2.状态管理
    3.开发进阶--新特性
    4.渲染优化
    5.如何进行Flutter性能测试
    6.Flutter的UI渲染机制
    7.Flutter性能监控
    8.Flutter性能优化常见方式总结
自己抽时间看 -- 问老师，bbs，群里面


flutter UI框架 --- Glide


科大讯飞语音插件
flutter --- native

flutter点击 ---》 Android 弹土司 ---》 土司的内容，flutter传过去，通过Android获取的本地时间

flutter:
    1.获取本地时间 --》 Android  调用本地方法获取数据
    2.将数据传给Android 显示
android:Toast.makeText("msg");

1.flutter 创建MethodChannel
2.调用 _methodChannel.invokeMethod
3.android 创建MethodChannel
4.onMethodCall


1.jar,so 
2.strings.xml
3.权限
4.
















