

同学们好，欢迎来到享学课堂，我是今天的主讲 Leo老师，

我们正式 上课的时间 20：05，已经进来的同学请耐心等候下其他同学


// 数据管理
HomePageViewModel --》 BaseListViewModel --》 BaseChangeNotifier


代码 --- 作为字典 参考

作业：
1.美化 播放器的 UI--参考代码
2.加一个右边上下滑动改变音量大小


一定要多敲代码







